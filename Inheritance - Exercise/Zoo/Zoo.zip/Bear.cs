﻿namespace Zoo
{
    public class Bear : Mammal
    {
        public Bear(string name) : base(name)
        {
            Name = name;
        }
        override public string Name { get { return Name; } }
    }
}
